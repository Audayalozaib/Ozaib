<?php
// إعادة التوجيه إلى صفحة تسجيل الدخول
header('Location: login.php');
exit;
?>
